package controller;
import view.View;

/**
 * Main Class instantiates the view
 * @author Kevin Doak
 *
 */
public class Main {
	public static void main(String[] Args) {
		View x = new View();		
		x.play();
	}//main
}//Class Main